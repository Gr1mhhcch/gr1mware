# CLEAN_Phobos_1.9.0-BUILDABLE-SRC

Buildable src reconstructed from the clean Phobos 1.9.0 jar. Full buildable and functional, jar in releases is built from this clean src. 




How to build:


Macos: 

./gradlew setupDecompWorkspace

./gradlew build



Windows: 

gradlew setupDecompWorkspace

gradlew build

