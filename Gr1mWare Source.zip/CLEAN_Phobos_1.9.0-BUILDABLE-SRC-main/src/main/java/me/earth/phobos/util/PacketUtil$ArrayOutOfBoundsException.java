package me.earth.phobos.util;

public class PacketUtil$ArrayOutOfBoundsException
        extends RuntimeException {
}

